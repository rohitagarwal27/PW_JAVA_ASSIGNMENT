class Pw
{
public void main()
{
sout
}
}